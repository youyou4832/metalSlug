#include "stdafx.h"
#include "scene.h"


HRESULT scene::init()
{
	return E_NOTIMPL;
}

void scene::release()
{
}

void scene::update()
{
}

void scene::render(HDC hdc)
{
}

scene::scene()
{
}


scene::~scene()
{
}
